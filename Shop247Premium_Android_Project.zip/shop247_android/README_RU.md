# Симулятор Магазина 24/7 — Android Premium

Это проект Android-приложения на базе загруженной HTML-игры. Внутри WebView запускается оригинальная игра; добавлена чёрно-золотая премиум-палитра, полноэкранный режим и сохранение прогресса через localStorage.

## Как получить APK

1. Установите Android Studio на компьютер.
2. Распакуйте архив `Shop247Premium_Android_Project.zip`.
3. В Android Studio выберите **Open** и откройте папку `shop247_android` (папку с `settings.gradle`).
4. Дождитесь синхронизации Gradle. При запросе установите Android SDK Platform 35 и подходящий Android Gradle Plugin.
5. Выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK будет в `app/build/outputs/apk/debug/app-debug.apk`.

## Важно

В этой среде нет установленного Android SDK/Gradle, поэтому готовый APK здесь скомпилировать не удалось. Архив содержит исходный Android-проект, который можно собрать в Android Studio. Интернет-разрешение не требуется: игра работает локально. Прогресс сохраняется на устройстве в хранилище WebView; очистка данных приложения удалит сохранение.
